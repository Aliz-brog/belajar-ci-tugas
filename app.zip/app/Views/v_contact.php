

<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
ini halaman Contact
<h2>Hubungi Kami</h2>
    <p>Silakan hubungi kami melalui email: Alif@gmail.com</p>
<?= $this->endSection() ?>
