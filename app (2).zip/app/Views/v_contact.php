

<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
ini halaman Contact
<h2>Hubungi Kami</h2>
Silakan hubungi kami melalui email: radit@gmail.com</p>
<?= $this->endSection() ?>
